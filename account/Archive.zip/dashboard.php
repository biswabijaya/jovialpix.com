<?php
header("Location: profile");
?>
