<?php
include("../includes/db.php");

if (isset($_POST['view']) and $_POST['view']=='country') {
  echo '<option value="">Select Country</option>';
  if ($result=mysqli_query($mysqli,"SELECT * from countries")) {
    while ($row=mysqli_fetch_array($result)) {
      echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
    }
  }
}

if (isset($_POST['view']) and $_POST['view']=='state') {
  $cid=$_POST['cid'];
  echo '<option value="">Select State</option>';
  if ($result=mysqli_query($mysqli,"SELECT * from states where country_id=$cid")) {
    while ($row=mysqli_fetch_array($result)) {
      echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
    }
  }
}

if (isset($_POST['view']) and $_POST['view']=='city') {
  $sid=$_POST['sid'];
  echo '<option value="">Select City</option>';
  if ($result=mysqli_query($mysqli,"SELECT * from cities where state_id=$sid")) {
    while ($row=mysqli_fetch_array($result)) {
      echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
    }
  }
}
?>
