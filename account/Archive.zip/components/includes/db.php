<?php
if(!isset($_SESSION)) { session_start(); }

//set timezone
date_default_timezone_set('Asia/Kolkata');
setlocale(LC_MONETARY, 'en_US');

$databaseHost = 'localhost';
$databaseName = 'u953863824_jovia';
$databaseUsername = 'u953863824_lpix';
$databasePassword = 'H4PFxLkHfnqT2ygHrH';

$mysqli =  mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

$_SESSION['DIR']="jovialpix.com";
$cname="JovialPix";
$active=" ";

function getToken($length){
   $token = "";
   $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
   $codeAlphabet.= "0123456789";
   $max = strlen($codeAlphabet); // edited
  for ($i=0; $i < $length; $i++) {
      $token .= $codeAlphabet[random_int(0, $max-1)];
  }

  return $token;
}
?>
