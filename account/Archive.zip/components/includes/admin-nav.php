<li class="nav-item <?php if ($active=='orders') echo 'active';  ?>" data-toggle="tooltip" data-placement="right" title="Orders">
  <a class="nav-link" href="orders">
    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
    <span class="nav-link-text">Orders</span>
  </a>
</li>
<li class="nav-item <?php if ($active=='users') echo 'active';  ?>" data-toggle="tooltip" data-placement="right" title="Users">
  <a class="nav-link" href="users">
    <i class="fa fa-users" aria-hidden="true"></i>
    <span class="nav-link-text">Users</span>
  </a>
</li>
<li class="nav-item <?php if ($active=='products') echo 'active';  ?>" data-toggle="tooltip" data-placement="right" title="Product Management">
  <a class="nav-link" href="products">
    <i class="fa fa-database" aria-hidden="true"></i>
    <span class="nav-link-text">Products</span>
  </a>
</li>
<li class="nav-item <?php if ($active=='shipment') echo 'active';  ?>" data-toggle="tooltip" data-placement="right" title="Shipping Management">
  <a class="nav-link" href="shipment">
    <i class="fa fa-database" aria-hidden="true"></i>
    <span class="nav-link-text">Shipping</span>
  </a>
</li>
