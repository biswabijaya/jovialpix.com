<!-- Footer-->
<footer class="sticky-footer">
  <div class="container">
    <div class="text-center">
      <small> © <?php echo date('Y'); ?> <?php echo $cname; ?> | Made With <i class="fa fa-fw fa-heart" style="color:red;"></i> By <a href="https://www.biswabijaya.com">Biswabijaya</a> </small>
    </div>
  </div>
</footer>
