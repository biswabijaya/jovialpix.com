<li class="nav-item <?php if ($active=='orders') echo 'active';  ?>" data-toggle="tooltip" data-placement="right" title="Orders">
  <a class="nav-link" href="orders">
    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
    <span class="nav-link-text">My Orders</span>
  </a>
</li>
