<li class="nav-item <?php if ($active=='blogs') echo 'active';  ?>" data-toggle="tooltip" data-placement="right" title="Blog Posts">
  <a class="nav-link" href="blogs">
    <i class="fa fa-rss" aria-hidden="true"></i>
    <span class="nav-link-text">Blogs</span>
  </a>
</li>
